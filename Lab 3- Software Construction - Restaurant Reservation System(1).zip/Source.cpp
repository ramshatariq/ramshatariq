#include <iostream>
using namespace std;
#include<string>
class restaurant{
	int servers, maxtime, tables, appetizers, soup, main_course_dishes, side_dishes, deserts,chef,servers,manager,otherstaff; 
	string startime, endtime;
		restaurant(){//constructor
			appetizers = 4, soup = 2, main_course_dishes = 12, side_dishes = 3, deserts = 4;
			chef = 4; servers = 6; manager = 1; otherstaff = 10;
		}
		int checktime(int s){

			if (s)


		}


};
class table{
	int exlarge, large, medium, small;
	table(){ exlarge = 12; large = 6; medium = 4; small = 2; }


	



};