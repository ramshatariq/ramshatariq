#include<iostream>
using namespace std;
#include <string>
class table
	//tables that people will book
{
	public:int exlarge, large, medium, small, exlarge_num, large_num, medium_num, small_num;
	table()//constructor
	{
		exlarge = 12;
		large = 6;
		medium = 4;
		small = 2;
		exlarge_num = 1;
		large_num = 3;
		medium_num = 8;
		small_num = 4;
	}
	void optimal_alloc(int people){
		//this function allocates table to people based on their number
		while (people > 0)
		{
			
			if (people >= 12){ System.out.println ("Allocated table exlarge\n"); people = people - 12; continue; }
			if (people >= 6){ System.out.println("Allocated table large\n"); people = people - 6; continue; }
			if (people >= 4){ System.out.println ("Allocated table medium\n"); people = people - 4; continue; }
			if (people >= 2){ System.out.println("Allocated table small\n"); people = people - 2; continue; }
			
		}

	}
};//end class
class online_reservation{
public:
	int appetizers, soup, main_course_dishes, side_dishes, deserts, chef, servers, manager, otherstaff,max_time;
	table t; string day;
	
	online_reservation()//constructor
	{
		appetizers = 4;
		soup = 2;
		main_course_dishes = 12;
		side_dishes = 3;
		deserts = 4;
		max_time = 30;
		chef = 4; 
		servers = 6; 
		manager = 1; 
		otherstaff = 10;
	}
	bool max_time(int t)//this function ensures that maximum time is 30 minutes
	{
		if (t > 30){
			System.out.println("Error\n");
		return false;
	}
 else return true;
	}
	int holiday(string day){
		if (day == "Sunday" || day == "Saturday")
		{ 
			System.out.println("Sorry restaurant is closed\n");
			return 0;
		}
		return 1;
}
	int time(float time)//check if time is between 11:00am � 10 : 00pm
	{
		if (time > 11 && time < 22)
		{
			System.out.println("time is appropriate\n");
			return 1;
		}
		else return 0;//time is either too late or too early
}
	bool ambiguity(int time,string date){
		int t; string d;
		if (t == time && d == date) return false; else return true;

	}
	bool takeorder()
	//Take order from customers
	{
		int time,people; string date;
		string food;
		System.out.println("Enter what food item you will have to eat?");
		food= System.console().readLine();
		System.out.println("Enter at what time and date will you come?");
		time = System.console().readLine();
		date = System.console().readLine();
			System.out.println( "How many number of people will there be?");
			people=System.console().readLine(); return true;
			bool b=ambiguity(time, date);
			if (b == true) return true; else return false;
	}
	void print_menu(){//it prints menu for customers
		System.out.println( "we provide 4 appetizers, 2 soup,12 main_course_dishes, 3 side_dishes and 4 deserts.\n");

	}
	void print_monthly_schedule(string d,string t,string n)
	//Once a schedule has been generated allow the staff to print a monthly schedule, listing the dates, times and the guest names 
	//for the reservations.
	{
		System.out.println("Dates:"); 
		System.out.println(d); 
		System.out.println("Times:");
		System.out.println(t); 
		System.out.println("Guest names:");
		System.out.println(n);
	}
}; //end class
online_reservation hotel;//hotel that has online reservation.It is global variable


//following are unit tests:
void test_day()//this unit test checks if function "holiday" has correct outputs or not
{
	int value1 = hotel.holiday("Friday"); 
	int value2 = hotel.holiday("Saturday");
	if (value1 == 1 && value2 == 0){ System.out.println("Unit test passed\n"); }
	else System.out.println("Unit test failed\n");
}
void test_time()//this unit test checks if function "time" has correct outputs or not
{
	int p = hotel.time(9);
	int q = hotel.time(22.5);
	int r = hotel.time(17);
	if (p == 0 && q == 0 && r == 1)
		System.out.println("Unit test passed\n");
	else System.out.println("Unit test failed\n");
}
void test_takeorder(){//this unit test checks if function "takeorder" has correct outputs or not
	bool a =hotel.takeorder();//we give them same date and time in both cases
	bool b =hotel.takeorder();
	if (a == true && b == false)
		System.out.println("test passed\n");
	if (a == true && b == true)
		System.out.println("test failed\n");
}
void test_max_time()//this unit test checks if function "test_max_time" has correct outputs or not
{
	bool a = hotel.max_time(40);
	bool b = hotel.max_time(20);
	if (a == false && b == true)
		System.out.println("test passed");
	else
	System.out.println("test failed");
}

 package lab03;
import java.sql.*;

public class Main {
	public static void main(String[] args) {
		String DB_URL = "jdbc:mysql://localhost/";
		String DB_USER = "root";
		String DB_PASS = "";

		Connection conn = null;
		Statement stmt = null;

		try{
			Class.forName("com.mysql.jdbc.Driver");

			conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS);
			stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery("SELECT * FROM sakila.actor ");

			while (rs.next())
				System.out.println(rs.getString("first_name"));

		}
		catch (Exception e){
			e.printStackTrace();
		}
		finally {

		}
	}
}